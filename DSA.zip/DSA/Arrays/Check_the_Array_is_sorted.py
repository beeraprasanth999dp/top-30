def arrays(arr,n):
    for i in range(1,n):
        if arr[i]<=arr[i-1]:
            return False
       
    return True
arr=[1,2,5,4]
n=len(arr)

print("True" if arrays(arr,n) else "False")