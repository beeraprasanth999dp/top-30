def appersOnes(arr):
    n=len(arr)
    for i in range(n):
        num=arr[i]
        cnt=0
        for j in range(n):
          if arr[j]==num:
              cnt+=1
        if cnt==1:
            return num
    return -1
arr=[1,1,0,0,2,4,5,4,5]
print(appersOnes(arr))
