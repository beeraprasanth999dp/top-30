def inversep(a,n):
    cnt=0
    for i in range(n):
        for j in range(i+1,n):
            if a[i]>2*a[j]:
                cnt+=1
    return cnt
def tempa(skill: [int],n: int)->int:
    return inversep(skill,n)
a= [4, 1, 2, 3, 1]
n=len(a)
cnt=tempa(a,n)
print(cnt)