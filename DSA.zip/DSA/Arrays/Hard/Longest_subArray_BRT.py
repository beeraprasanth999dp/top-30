def solve(a):
    maxi=0
    sum_indx={}
    s=0
    for i,val in enumerate(a):
        s+=val
        if s==0:
            maxi=i+1
        elif s in sum_indx:
            maxi=max(maxi,i-sum_indx[s])
        else:
            sum_indx[s]=i
    return  maxi
a=[9,-3,3,-1,6,-5]
res=solve(a)
print(res)