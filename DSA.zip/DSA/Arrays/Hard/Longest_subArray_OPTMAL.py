def countsubarray(a,k):
    freq={0:1}
    prefixor=0
    count=0
    for i in a:
        prefixor ^= i
        target =prefixor ^k
        if target in freq:
            count+=freq[target]
        freq[prefixor]=freq.get(prefixor,0)+1
    return count
a=[4,2,2,6,4]
k=6
print(countsubarray(a,k))