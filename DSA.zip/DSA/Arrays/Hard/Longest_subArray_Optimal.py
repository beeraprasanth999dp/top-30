def subArray(a,n):
    mpp:dict[a,n]={}
    maxi=0
    s=0
    for i in range(n):
        s+=a[i]
        if s==0:
            maxi=i+1
        elif s in mpp:
            maxi=max(maxi,i-mpp[s])
        else:
            mpp[s]=i
    return  maxi
a=[9,-3,3,-1,6,-5]
n=len(a)
print(subArray(a,n))