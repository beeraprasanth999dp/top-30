def xor(a,b):
    count=0
    n=len(a)
    for i in range(n):
        xorVal=0
        for j in range(i,n):
            xorVal ^=a[j]
            if xorVal==b:
                count+=1
    return count
a=[4,2,2,6,4]
b=6
print(xor(a,b))