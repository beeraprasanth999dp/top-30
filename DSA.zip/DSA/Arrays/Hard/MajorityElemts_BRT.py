def majority(nums):
    n=len(nums)
    result=[]
    for i in range(n):
        if len(result)==0 or result[0]!=nums[i]:
            cnt=0
            for j in range(n):
                if nums[i]==nums[j]:
                    cnt+=1
            if cnt>(n//3):
                result.append([i])
        if len(result)==2:
            break
    return result


arr = [11,55, 33, 33, 11, 33, 11]



ans = majority(arr)

# Print the majority elements found
print("The majority elements are:", end=" ")
for it in ans:
    print(it, end=" ")
print()
