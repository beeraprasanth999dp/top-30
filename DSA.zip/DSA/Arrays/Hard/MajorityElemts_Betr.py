from collections import defaultdict
from typing import List
def major(nums):
    n=len(nums)
    result=[]
    mpp=defaultdict(int)
    mini = n // 3 + 1
    for i in nums:
        mpp[i]+=1
        if mpp[i]==mini:
            result.append(i)
        if len(result)==2:
            break
    return result


nums = [11, 33, 33, 11, 33, 11]




ans = major(nums)


print("The majority elements are:", *ans)
