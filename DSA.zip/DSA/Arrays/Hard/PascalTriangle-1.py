def pascels(numrows):
    triangle=[]
    for i in range(numrows):
        row=[1]*(i+1)
        for j in range(1,i):
            row[j]=triangle[i-1][j-1]+triangle[i-1][j]
        triangle.append(row)
    return triangle
n=5
result=pascels(n)
for row in result:
    print(" ".join(map(str,row)))