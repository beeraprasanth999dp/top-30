def pascel(N):
    row=[]
    val=1
    row.append(val)
    for k in range(1,N):
        val=val*(N-k)//k
        row.append(val)
    return row
N=5
result=pascel(N)

print(*result)