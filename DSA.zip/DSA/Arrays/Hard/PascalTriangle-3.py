def pascel(r,c):
    n=r-1
    k=c-1
    result=1
    for i in range(k):
        result*=(n-i)
        result//=(i+1)
    return result
r,c=5,3
print(pascel(r,c))