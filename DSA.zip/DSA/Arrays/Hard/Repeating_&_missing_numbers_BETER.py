#By hashing
def mr(arr):
    n=len(arr)
    hash=[0]*(n+1)
    repeating=-1
    missing=-1
    for num in arr:
        hash[num]+=1

    for i in range(1,n+1):
        if hash[i]==2:
            repeating=i
        elif hash[i]==0:
            missing=i
        if(repeating!=-1 and missing !=-1):
            break
    return(repeating,missing)
arr=[1,2,3,4,6,1]
mr(arr)
print(mr(arr))