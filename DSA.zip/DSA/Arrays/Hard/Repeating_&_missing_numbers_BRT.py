def mr(arr):
    n=len(arr)
    repeating=-1
    missing=-1
    for i in range(1,n+1):
        cnt=arr.count(i)
        if cnt==2:
            repeating=i
        elif cnt==0:
            missing=i
        if(repeating !=-1 and missing !=-1):
            break
    return(repeating,missing)
arr=[1,2,3,4,6,1]
mr(arr)
print(mr(arr))

