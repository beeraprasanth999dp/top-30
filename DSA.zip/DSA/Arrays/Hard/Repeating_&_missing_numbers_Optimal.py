def mr(arr):
    n=len(arr)
    sn=n*(n+1)//2
    s2n=n*(n+1)*(2*n+1)//6
    s,s2=0,0
    for num in arr:
        s+=num
        s2+=num*num
    val1=s-sn
    val2=s2-s2n
    val2=val2//val1
    x=(val1+val2)//2
    y=x-val1
    return{int(x),int(y)}
arr = [3, 1, 2, 5, 4, 6, 7, 5]
mr(arr)
print(mr(arr))

