def threesum(arr):
    n=len(arr)
    st=set()
    for i in range(n):
        hashset=set()
        for j in range(i+1,n):
            third= -(arr[i]+arr[j])
            if third in hashset:
                triplet=tuple(sorted([arr[i],arr[j],third]))
                st.add(triplet)
            hashset.add(arr[j])
    return [list(triplet) for triplet in st]
arr=[-2,-2,-2,-1,-1,-1,0,0,0,1,1,1,2,2,2]
res=threesum(arr)
for triplet in res:
    print(triplet)