def Threesum(arr):
    n=len(arr)
    st=set()
    for i in range(n):
        for j in range(i+1,n):
            for k in range(j+1,n):
                if(arr[i]+arr[j]+arr[k]==0):
                    triplet=tuple(sorted([arr[i],arr[j],arr[k]]))
                    st.add(triplet)
    return [list(triplet) for triplet in st]
arr = [-1, 0, 1, 2, -1, -4]
res=Threesum(arr)
for triplet in res:
    print(triplet)