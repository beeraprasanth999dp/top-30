def fourSum(arr,target):
    n=len(arr)
    st=set()

    for i in range(n):
        for j in range(i+1,n):
            hashset=set()
            for k in range(j+1,n):
                total=target-arr[i]-arr[j]-arr[k]
                if total in hashset:
                    temp=tuple(sorted([arr[i],arr[j],arr[k],total]))
                    st.add(temp)
                hashset.add(arr[k])
    return [list (tem)  for tem in st]
arr=[1,0,-1,-2,2]
target=0
res=fourSum(arr,target)
print(res)