def foutSum(arr,target):
    n=len(arr)
    st=set()
    for i in range(n):
        for j in range(i+1,n):
            for k in range(j+1,n):
                for l in range(k+1,n):
                    if(arr[i]+arr[j]+arr[k]+arr[l]==target):
                        triplet=tuple(sorted([arr[i],arr[j],arr[k],arr[l]]))
                        st.add(triplet)
    return [list(triplet) for triplet in st]
arr = [1, 0, -1, 0, -2, 2]
target=0
res=foutSum(arr,target)
for tri in res:
    print(tri)

