def fourSum(arr,target):
    n=len(arr)
    ans=[]
    arr.sort()
    for i in range(n):
        if i>0 and arr[i]==arr[i-1]:
            continue
        for j in range(i+1,n):
            if j>i+1 and arr[j]==arr[j-1]:
                continue
            left=j+1
            right=n-1
            while left < right:
                total=arr[i]+arr[j]+arr[right]+arr[left]
                if total ==target:
                    ans.append([arr[i],arr[j],arr[left],arr[right]])
                while left <right and arr[left]==arr[left+1]:
                    left+=1
                while right < right and arr[right]==arr[right-1]:
                    right-=1

                left+=1
                right-=1

                if total < target:
                    left+=1
                else:
                    right-=1
    return ans
arr = [1, 0, -1, 0, -2, 2]
target = 0

res=fourSum(arr,target)
print(res)