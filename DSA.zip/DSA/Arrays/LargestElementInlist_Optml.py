def largst(arr,n):

    max=arr[0]
    for i in range(1,n):

        if(arr[i] > max):
            max=arr[i]

    return max

arr=[2,5,3,6,7,5]
print(arr)
n=len(arr)
max=largst(arr,n)
print(max)
#Optimal Way


