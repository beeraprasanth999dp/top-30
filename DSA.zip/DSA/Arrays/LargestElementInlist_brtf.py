def largest(arr):
    arr.sort()
    return arr[-1]
arr=[2,5,6,4,3]
print(arr)
print(largest(arr))
#Brutforce Way