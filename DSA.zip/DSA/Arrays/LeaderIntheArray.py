def leaderArray(nums):
    ans=[]
    n=len(nums)
    for i in range(0,n):
        leader=True
        for j in range(i+1,n):
            if nums[j]>=nums[i]:
                leader=False
                break
        if leader:
            ans.append(nums[i])
    return ans
nums=[1,2,5,3,1,2]
print(leaderArray(nums))
#Tc=o(N^2)
#Sc=o(1)
