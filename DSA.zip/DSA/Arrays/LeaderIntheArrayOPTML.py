def leaders(nums):
    ans=[]
    maxi=nums[-1]
    ans.append(nums[-1])
    for i in range(len(nums)-2,-1,-1):
        if nums[i]>maxi:
            maxi=nums[i]
            ans.append(nums[i])
        ans.reverse()
    return ans
nums=[10,22,12,3,0,6]
print(leaders(nums))
#TC=O(N)
#SC=O(1)