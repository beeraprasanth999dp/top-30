#BruteForce
# def lftarray(arr,n):
#     temp=[0]*n
#     for i in range(1,n):
#         temp[i-1]=arr[i]
#     temp[n-1]=arr[0]
#     for num in temp:
#         print(num,end=" ")
#     print()
# n=5
# arr=[1,2,3,4,5]
# lftarray(arr,n)

#Optimal Approach________________________________________
def leftrotate(arr):
    temp=arr[0]
    for i in range(1,len(arr)):
        arr[i-1]=arr[i]
        arr[-1]=temp
arr=[1,2,3,4,5,6,7]
print(arr)
leftrotate(arr)
print(arr)

