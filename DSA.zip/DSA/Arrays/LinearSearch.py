num=5
arr=[1,2,4,6,7,5]
for i in range(1,len(arr)):
    if i==num:
        print(i)
