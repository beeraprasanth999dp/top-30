# arr=[2,2,3,3,1,2,2,3,3,3,3,3]
# n=len(arr)
# for i in range(0,n):
#     cnt=0
#     for j in range(0,n):
#         if arr[j]==arr[i]:
#             cnt+=1
# if(cnt >n/2):#using n/2
#     print(arr[i])
#===================================================
#Better opproach
def majority_element(nums):
    n=len(nums)
    mp={}
    for nums in nums:
        if nums in mp:
           mp[nums]+=1
        else:
            mp[nums]=1
    for num,count in mp.items():
        if count >n/2:
            return num
    return -1
nums=[2,2,1,1,1,2,2]
majority_element(nums)
print(nums)
print(majority_element(nums))

