def merge(nums1,m,nums2,n):
    i=m-1
    j=n-1
    k=m+n-1
    while i>=0 and j>=0:
        if nums1[i]>nums2[j]:
            nums1[k]=nums1[i]
            i-=1
        else:
            nums1[k]=nums2[j]
            j-=1
        k-=1
    while j>=0:
        nums1[k]=nums2[j]
        k-=1
        j-=1


nums1 = [1, 3, 5, 0, 0, 0]
nums2 = [2, 4, 6]
m, n = 3, 3
merge(nums1, m, nums2, n)
print(nums1)