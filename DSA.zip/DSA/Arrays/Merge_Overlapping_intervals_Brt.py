def overlapping(intervals):
    n=len(intervals)
    ans=[]
    i=0
    while i<n:
        start=intervals[i][0]
        end=intervals[i][1]
        j=i+1
        while j<n and intervals[j][0]<=end:
            end=max(end,intervals[j][1])
            j+=1
        ans.append([start,end])
        i=j
    return ans
intervals = [[1,3],[2,6],[6,7],[8,10],[15,18]]
print(overlapping(intervals))