def overlapping(intervals):

    intervals.sort()

    merged=[]
    for inerval in intervals:
        if not merged or merged[-1][1]<inerval[0]:
            merged.append(inerval)
        else:
            merged[-1][1]=max(
                merged[-1][1],
                inerval[1]
            )
    return merged
intervals = [[1,3],[2,6],[6,7],[8,10],[15,18]]
print(overlapping(intervals))