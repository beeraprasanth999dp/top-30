def missingNum(num):
    n=len(num)+1
    for i in range(1,n):
        flag=0
        for j in range(0,n-1):
            if num[j]==i:
                flag=1
                break
        if not flag:
            return i
    return -1
num=[1,2,3,4,6]
print(missingNum(num))

#optimal way===============================================
arr=[1,2,3,5]#optmial way using n natural numbers
n=len(arr)+1
total_sum=sum(arr)
expected_sum=n*(n+1)//2
missing_num=expected_sum-total_sum
print(missing_num)

