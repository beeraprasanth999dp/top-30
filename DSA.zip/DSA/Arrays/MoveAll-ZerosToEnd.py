def move(arr):
    res=[]
    for num in arr:
        if num !=0:
            res+=[num]
    while len(res)<len(arr):
        res+=[0]
    return res
arr=[0,1,0,3,12]
l=move(arr)
print(l)