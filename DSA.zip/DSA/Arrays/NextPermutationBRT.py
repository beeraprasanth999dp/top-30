from itertools import permutations
def nextpermutation(self,nums):
    prems=sorted(set(nextpermutation(nums)))
    current=tuple(nums)
    for i in range(len(prems)):
        if prems[i]==current:
            if i==len(prems)-1:
                return list(prems[0])
            return list(prems[i+1])
    return nums
nums=[1,2,3]
result=nextpermutation(self=nums)
print(result)