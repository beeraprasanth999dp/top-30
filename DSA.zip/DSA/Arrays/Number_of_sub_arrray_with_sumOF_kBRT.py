arr = [3, 1, 2, 4]
k=6
n=len(arr)
cnt=0
for i in range(n):
    for j in range(i,n):
        sum=0
        for k in range(i,j+1):
            sum+=arr[k]
        if sum==k:
            cnt+=1
print(cnt)
