arr=[3,1,2,4]
k=6
n=len(arr)
cnt=0
for i in range(n):
    sum=0
    for j in range(i,n):
        sum+=arr[j]
        if sum==k:
            cnt+=1
print(cnt)
