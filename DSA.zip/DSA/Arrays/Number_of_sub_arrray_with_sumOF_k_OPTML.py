arr=[3,1,2,4]
k=6
n=len(arr)
prifixsumcnt={}
prifixsum=0
cnt=0

prifixsumcnt[0]=1
for i in range(n):
    prifixsum+=arr[i]
    remove=prifixsum-k
    if remove in prifixsumcnt:
        cnt+=prifixsumcnt[remove]
    prifixsumcnt[prifixsum]=prifixsumcnt.get(prifixsum,0)+1
print(cnt)
