def reArranging(A):
    n=len(A)
    posInd=0
    negInd=1
    ans=[0]*n
    for i in range(n):
        if A[i]>0:
            ans[posInd]=A[i]
            posInd+=2
        else:
            ans[negInd]=A[i]
            negInd+=2
    return ans
A=[1,2,-3,3,-5,-6]
print(reArranging(A))