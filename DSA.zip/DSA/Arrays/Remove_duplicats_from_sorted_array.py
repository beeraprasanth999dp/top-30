def sortedArr(arr):
    i=0
    for j in range(1,len(arr)):
        if arr[j]!=arr[i]:
            arr[i+1]=arr[j]
            i+=1
    return  i+1
arr=[1,2,2,1,3,3,4,6,5,5]
print(arr)
k=sortedArr(arr)
print(arr[:k])