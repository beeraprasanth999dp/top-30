def rotatematrix(matrix):
    n=len(matrix)
    roatate=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            roatate[j][n-i-1]=matrix[i][j]
    return roatate
matrix=[
    [1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]

]
print(matrix)
rotated=rotatematrix(matrix)
for row in rotated:
    print(row)