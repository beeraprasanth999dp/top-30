def secondSmall(arr,n):
    if n<2:
        return -1
    small=float('inf')
    se_small=float('inf')
    for i in range(n):
        if arr[i]<small:
            se_small=small
            small=arr[i]
        elif arr[i]<se_small and arr[i]!=small:
            se_small=arr[i]
    return se_small
def secomdlarge(arr,n):
    if n<2:
        return -1
    large=float('-inf')
    se_large=float('-inf')
    for i in range(n):
        if arr[i]>large:
            se_large=large
            large=arr[i]
        elif arr[i]>se_large and arr[i]!= large:
            se_large=arr[i]
    return se_large
arr=[2,5,7,6,3]
print(arr)
n=len(arr)
print("SecondLarge",secomdlarge(arr,n))
print("SecondSmall",secondSmall(arr,n))