def second_smlg(arr,n):
    if n==0 or n==1:
        print(-1,-1)
        return
    small=float('inf')
    se_small=float('inf')
    large=float('-inf')
    se_large=float('-inf')
    for i in range(n):
        small=min(small,arr[i])
        large=max(large,arr[i])
    for i in range(n):
        if arr[i]<se_small and arr[i]!=small:
            se_small=arr[i]
        if arr[i]>se_large and arr[i]!=large:
            se_large=arr[i]
    print("Second smallest is:",se_small)
    print("Second Largest is:",se_large)
arr=[22,2,5,7,66,4,33]
print(arr)
n=len(arr)
second_smlg(arr,n)

