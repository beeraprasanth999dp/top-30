def zeromatrix(matrix):
    m=len(matrix)
    n=len(matrix[0])
    for i in range(m):
        for j in range(n):
            if matrix[i][j]==0:
                for col in range(n):
                    if matrix[i][col]!=0:
                        matrix[i][col]=-1
                for row in range(m):
                    if matrix[row][j]!=0:
                        matrix[row][j]=-1
    for i in range(m):
        for j in range(n):
            if matrix[i][j]==-1:
                matrix[i][j]=0
    for row in matrix:
        print(row)
matrix=[[1,1,1],[1,0,1],[1,1,1]]
# for rowo in matrix:
#     print(rowo)
print(zeromatrix(matrix))

