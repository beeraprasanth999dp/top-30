def zerosmatrix(matrix):
    m=len(matrix)
    n=len(matrix[0])
    first_row_zeros=False
    first_col_zeros=False
    for j in range(n):
        if matrix[0][j]==0:
            first_row_zeros=True
            break
    for i in range(m):
        if matrix[i][0]==0:
            first_col_zeros=True
            break
    for i in range(1,m):
        for j in range(1,m):
            if matrix[i][j]==0:
                matrix[i][0]=0
                matrix[0][j]=0
    if first_row_zeros:
        for  i in range(m):
            matrix[0][j]=0
    if first_row_zeros:
        for  i in range(m):
            matrix[i][0]=0
matrix=[[0,1,2,0],[3,4,5,2],[1,3,1,5]]
zerosmatrix(matrix)
for r in matrix:
    print(r)

