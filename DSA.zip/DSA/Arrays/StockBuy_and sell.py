def stock(price):#brute force
    n=len(price)
    maxprofit=0
    for i in range(n):
        for j in range(i+1,n):
            profit=price[j]-price[i]
            maxprofit=max(maxprofit,profit)
    return maxprofit
price=[7,1,5,3,6,4]
print("max profit",stock(price))