#hasing===================================
def two_sum(arr,target):
    mp={}
    for i,num in enumerate(arr):
        compli=target-num
        if compli in mp:
            return [mp[compli],i]#"yes"
        mp[num]=i
    return [-1,-1]

target=8
arr=[2,6,5,8,11]
print(two_sum(arr,target))