def two_sum(arr,target):
    n=len(arr)
    for i in range(n):
        for j in range(i+1,n):
            if i==j:
                continue
            elif(arr[i]+arr[j]==target):
                   return [i,j]#"yes"

    return [-1,-1]#"no"
target=15
arr=[1,3,6,7,9]
print(two_sum(arr,target))

