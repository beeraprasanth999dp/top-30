def Two_sum(arr,target):
    nums_with_index=[(num,idx) for idx,num in enumerate(arr)]
    nums_with_index.sort(key=lambda x:x[0])
    left=0
    right=len(arr)-1
    while left<right:
        current_sum=nums_with_index[left][0]+nums_with_index[right][0]
        if current_sum==target:
            return [nums_with_index[left][1], nums_with_index[right][1]]#"yes"
        elif current_sum<target:
            left+=1
        else:
            right -=1
    return [-1,-1]#"No"
target=14
arr=[2,6,5,8,11]
print(Two_sum(arr,target))
