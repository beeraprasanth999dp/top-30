arr=[-2,-3,4,-1,-2,1,5,-3]
maxi=float('-inf')
# for i in range(len(arr)):
#     for j in range(i,len(arr)):
#         sum=0
#         for k in range(i,j+1):
#             sum+=arr[k]
#         maxi=max(maxi,sum)
# print(maxi)
#tc=o(n)^3
#===========================================
#better Approach
for i in range(len(arr)):
    sum=0
    for j in range(i,len(arr)):
        sum+=arr[j]
        maxi=max(maxi,sum)
print(maxi)
