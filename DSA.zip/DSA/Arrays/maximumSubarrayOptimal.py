def maxSubarray(arr):
    maxi=float('-inf')
    sum=0
    for i in range(len(arr)):
        sum+=arr[i]
        if sum>maxi:
           maxi=sum
        if sum<0:
           sum=0
    return maxi
arr=[-2,-3,4,-1,-2,1,5,-3]
print(maxSubarray(arr))

