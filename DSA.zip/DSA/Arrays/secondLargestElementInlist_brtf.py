def selrgst(arr):
    arr.sort()

    return arr[-2]
def  sesmal(selrgst):
    return arr[2]


arr=[2,5,3,7,6,8]
print(arr)
print("second largest:",selrgst(arr))
print("second smallest",sesmal(arr))
#Brute Way
# arr=[2,5,6,7,7]
#
# print(sorted(arr))
# k=(set(arr))
# m=(list(k))
# print(m)
# print(m[-2])
