def order(nums):
    cnt0=cnt1=cnt2=0
    for i in nums:
        if i==0:
            cnt0 +=1
        elif i ==1:
            cnt1 +=1
        else:
            cnt2 +=1
    index=0
    for j in range(cnt0):
        nums[index]=0
        index+=1
    for j in range(cnt1):
        nums[index]=1
        index +=1
    for j in range(cnt2):
        nums[index]=2
        index +=1
nums=[1,0,2,1,0]
order(nums)
print(nums)