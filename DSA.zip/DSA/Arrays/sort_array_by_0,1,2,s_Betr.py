def order(nums):
    cnt0=cnt1=cnt2=0
    for i in nums:
        if i==0:
            cnt0+=1
        elif i==1:
            cnt1+=1
        else:
            cnt2+=1
    for i in range(cnt0):
        nums[i]=0
    for i in range(cnt0,cnt0+cnt1):
        nums[i]=1
    for i in range(cnt0+cnt1,len(nums)):
        nums[i]=2
nums=[2,2,0,0,0,1,1,1]
order(nums)
print(nums)