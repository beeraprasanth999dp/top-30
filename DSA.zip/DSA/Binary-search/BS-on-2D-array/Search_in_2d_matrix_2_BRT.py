def matrixt(arr,t):
    n=len(arr)
    m=len(arr[0])
    for i in range(n):
        for j in range(m):
            if arr[i][j]==t:
                return True
    return False
arr=[[1,4,7,11],[2,5,8,12],[3,6,9,16],[10,13,14,17]]
t=9
print(matrixt(arr,t))