def binarysearch(arr,t):
    n=len(arr)
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if arr[mid]==t:
            return True
        elif arr[mid]<t:
            low=mid+1
        else:
            high=mid-1
    return False
def search(arr,t):
    for i in range(0,len(arr)):
        if binarysearch(arr[i],t):
            return True
    return False
arr=[[1,4,7,11],[2,5,8,12],[3,6,9,16],[10,13,14,17]]
t=4
print(search(arr,t))


