def matrixx(arr,t):
    n=len(arr)
    m=len(arr[0])
    row=0
    col=m-1
    while(row<n and col >=0):
        if(arr[row][col]==t):
            return[row,col]
        elif(arr[row][col]<t):
            row+=1

        else:
            col-=1
    return [-1,-1]
arr=[[1,4,7,11],[2,5,8,12],[3,6,9,16],[10,13,14,17]]
t=9
print(matrixx(arr,t))
