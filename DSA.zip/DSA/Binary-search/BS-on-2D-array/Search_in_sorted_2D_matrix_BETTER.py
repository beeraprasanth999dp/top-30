def binarySearch(arr,target):
    n=len(arr)

    low=0
    high=n-1
    while low<=high:
        mid=(low+high)//2
        if arr[mid]==target:
            return True
        elif target>arr[mid]:
            low=mid+1
        else:
            high=mid-1
    return False
def TargetMatrix(Matrix,Traget):
    n=len(Matrix)
    m=len(Matrix[0])
    for i in range(n):
        if Matrix[i][0]<=Traget<=Matrix[i][m-1]:
            return binarySearch(Matrix[i],Traget)
    return False
Matrix=[[1,2,3]
        ,[22,45,66],[12,54,67]]
Traget=66
print(TargetMatrix(Matrix,Traget))