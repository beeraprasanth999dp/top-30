def targetSearch(matrix,target):
    n=len(matrix)
    m=len(matrix[0])
    for i in range(n):
        for j in range(m):
            if(matrix[i][j]==target):
                
                return True

    return False
matrix=[[1,2,3]
        ,[22,45,66],[12,54,67]]
target=66
print(targetSearch(matrix,target))