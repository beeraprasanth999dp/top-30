def max_numberOnes(matrix,n,m):
    cnt_max=0
    index=-1
    for i in range(n):
        cnt_ones=0
        for j in range(m):
            cnt_ones+=matrix[i][j]
        if cnt_ones>cnt_max:
            cnt_max=cnt_ones
            index=i
    return index
matrix=[[0,1,0],
        [0,0,1],
        [1,1,0]]
n,m=3,3
print("index:",max_numberOnes(matrix,n,m))