def lower_bound(arr,n,x):
    low=0
    high=n-1
    ans=n
    while low<=high:
        mid=(low+high)//2
        if arr[mid]>=x:
            ans=mid
            high=mid-1
        else:
            low=mid+1
    return ans
def maxOnes(matrix,n,m):
    cnt_max=0
    index=-1
    for i in range(n):
        cnt_ones=m-lower_bound(matrix[i],m,1)
        if cnt_ones>cnt_max:
            cnt_max=cnt_ones
            index=i
    return index
matrix=[[0,1,0],
        [0,0,1],
        [1,1,0]]
n,m=3,3
print("index:",maxOnes(matrix,n,m))
