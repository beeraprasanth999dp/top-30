def kthMisiing(arr,k):
    for num in arr:
        if num<=k:
            k+=1
        else:
            break
    return k
arr=[4,7,9,10]
k=4
ans=kthMisiing(arr,k)
print(ans)