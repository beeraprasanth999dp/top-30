import math


def miniEatingSpedd(piles,h):
    maxi=max(piles)
    for speed in range(1,maxi+1):
        total_hr=0
        for pile in piles:
            total_hr+=math.ceil(pile/speed)
        if total_hr<=h:
            return speed
piles=[3,6,7,11]
h=8
print(miniEatingSpedd(piles,h))