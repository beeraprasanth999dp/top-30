def minEatingSpeed(piles,h):
    low=1
    high=max(piles)
    while(low<=high):
        mid=(low+high)//2
        total_hrs=0
        for pile in piles:
            total_hrs+=(pile+mid-1)//mid
        if total_hrs<=h:
            high=mid-1
        else:
            low=mid+1
    return low
piles=[3,6,7,11]
h=8
print(minEatingSpeed(piles,h))