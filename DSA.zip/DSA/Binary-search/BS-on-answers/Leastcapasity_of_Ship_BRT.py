def leastCapasity(weights,d):
    max_cap=max(weights)
    total=sum(weights)
    for capacity in range(max_cap,total+1):
        load=0
        day=1

        for w in weights:

            if load+w>capacity:
                day+=1
                load=w
            else:
                load+=w
        if day<=d:
            return capacity
    return -1
weights=[1,2,3,4,5,6,7,8,9,10]
d=5
print(leastCapasity(weights,d))