def leastload(weight,d):
    low=max(weight)
    high=sum(weight)
    while(low<=high):
        mid=(low+high)//2
        day=1
        load=0
        for w in weight:
            if load+w>mid:
                day+=1
                load=w
            else:
                load+=w
        if day<=d:
            high=mid-1
        else:
            low=mid+1
    return low
weight=[1,2,3,4,5,6,7,8,9,10]
d=5
print(leastload(weight,d))
