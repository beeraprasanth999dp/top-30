def nth(x):
    ans=-1
    for i in range(1, x+1):
        power=i**3
        if power==x:

            return i
        elif power>x:
            break

    return ans
print(nth(125))