def nth(n,x):
    low=1
    high=x
    while(low<=high):

        mid=(low+high)//2
        ans = 1
        for _ in range(n):
            ans*=mid
            if ans>x:
                break
        if ans==x:
            return mid
        elif ans <x:
            low=mid+1
        else:
            high=mid-1
    return -1
res=nth(3,125)
print(res)


