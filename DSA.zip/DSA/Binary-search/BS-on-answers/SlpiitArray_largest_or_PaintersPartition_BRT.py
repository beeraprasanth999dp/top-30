def count_parts(arr,max_sum):
    parts=1
    current=0
    for num in arr:
        if current+num <=max_sum:
            current+=num
        else:
            parts+=1
            current=num
    return parts
def largest_subarr(arr,k):
    low=max(arr)
    high=sum(arr)
    for max_sum in range(low,high+1):
        if count_parts(arr,max_sum)==k:
            return max_sum
    return low
arr=[10,20,30,40]
k=2
ans=largest_subarr(arr,k)
print(ans)