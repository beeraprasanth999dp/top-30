def count_partition(arr,max_sum):
    parts=1
    current=0
    for num in arr:
        if current+num<=max_sum:
            current+=num
        else:
            parts+=1
            current+=num
    return parts
def lg_subarr_sum_maxarr(arr,k):
    low=max(arr)
    high=sum(arr)
    while low<=high:
        mid=(low+high)//2
        parts=count_partition(arr,mid)
        if parts>k:
            low=mid+1
        else:
            high=mid-1
    return low
arr=[10,20,30,20]
k=2
ans=lg_subarr_sum_maxarr(arr,k)
print(ans)