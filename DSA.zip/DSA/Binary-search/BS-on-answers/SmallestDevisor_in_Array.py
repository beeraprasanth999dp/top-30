import math


def smallestDevisor(arr,threshold):
    maxi=max(arr)
    
    for d in range(1,maxi+1):
        total=0
        for num in arr:
            total+=math.ceil(num/d)
        if total<=threshold:
            return d
    return -1
arr=[1,2,3,4,5]
threshold=8
res=smallestDevisor(arr,threshold)
print(res)



