import math


def dout(arr,divisor):

     return sum(math.ceil(x/divisor) for x in arr)
def smallestdevi(arr,threshold):
    if(len(arr)>threshold):
        return -1
    low=1
    high=max(arr)
    while(low<=high):
        mid=(low+high)//2
        if(dout(arr,mid)<=threshold):

            high=mid-1
        else:
            low=mid+1
    return low
arr=[1,2,3,4,5]
threshold=8
print(smallestdevi(arr,threshold))

