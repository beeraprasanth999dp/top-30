def sqrt(n):
    ans=1
    for i in range(n):
        if(i*i<=n):
            ans=i

        else:
            break
    return ans
print(sqrt(17))
