def sqrt(x):
    if x<2:
        return x
    low=1
    high=x
    ans=0
    while(low<=high):
        mid=(low+high)//2
        if(mid*mid<=x):
            ans=mid
            low=mid+1
        else:
            high=mid-1
    return ans
print(sqrt(29))