def acc(arr,x):
    n=len(arr)
    cnt=0
    for i in range(n):
        if(arr[i]==x):
            cnt+=1
    return cnt
arr=[1,2,3,4,5,5,6,5,7]
x=5
print(acc(arr,x))
