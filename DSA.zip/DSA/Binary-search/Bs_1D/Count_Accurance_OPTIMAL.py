def first(arr,x):
    n=len(arr)
    low=0
    high=n-1
    first=-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]==x):
            first=mid
            high=mid-1# <mid
        elif(x<arr[mid]):
            high=mid-1
        else:
            low=mid+1
    return first

def last(arr,x):
    n=len(arr)
    res=-1
    low,high=0,n-1
    while(low<=high):

        mid=(low+high)//2
        if(arr[mid]==x):
            res=mid
            low=mid+1#**** > mid
        elif(x < arr[mid]):
            high=mid-1
        else:
            low=mid+1
    return res
def firstAndlast(arr,x):
    f=first(arr,x)
    if f==-1:
        return(-1,-1)
    l=last(arr,x)
    return (f,l)
def count(arr,x):
    f,l=firstAndlast(arr,x)
    if f==-1:
        return 0
    return l-f+1
arr = [2, 4, 6, 8, 8, 8, 11, 13]

x = 8
ans = count(arr, x)
print("The number of occurrences is:", ans)