def flst(arr,x):
    n=len(arr)
    first=-1
    last=-1
    for i in range(0,n-1):
        if(arr[i]==x):
            first=i
            break
            # if(arr[i]==x):
            #     last=i

    return first
arr=[2,4,6,8,8,8,11,13]
x=8
res=flst(arr,x)
print(res)