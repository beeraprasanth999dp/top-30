def last(arr,x):
    n=len(arr)
    res=-1
    low,high=0,n-1
    while(low<=high):

        mid=(low+high)//2
        if(arr[mid]==x):
            res=mid
            low=mid+1#**** > mid
        elif(x < arr[mid]):
            high=mid-1
        else:
            low=mid+1
    return res
def first(arr,x):
    n=len(arr)
    low=0
    high=n-1
    first=-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]==x):
            first=mid
            high=mid-1# <mid
        elif(x<arr[mid]):
            high=mid-1
        else:
            low=mid+1
    return first
arr=[2,4,6,8,8,8,11,13,13]
x=8
res1=first(arr,x)
res=last(arr,x)
print("first:",res1,"last:",res)