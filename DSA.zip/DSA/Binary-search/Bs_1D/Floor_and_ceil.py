def floor(arr,x):
    n=len(arr)
    ans=-1
    low,high=0,n-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]<=x):
            ans=arr[mid]
            low=mid+1
        else:
            high=mid-1
    return ans
def ceil(arr,x):
    n = len(arr)
    ans = -1
    low, high = 0, n - 1
    while (low <= high):
        mid = (low + high) // 2
        if (arr[mid] >= x):
            ans = arr[mid]
            high = mid - 1
        else:
            low = mid + 1
    return ans
arr = [3, 4, 4, 7, 8, 10]
x = 5
k=floor(arr,x)
j=ceil(arr,x)
print("floor:",k)
print("ceil:",j)

