def lowerbound(arr,x):
    n=len(arr)
    ans=n
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]>=x):
            ans=mid
            high=mid-1
        else:
            low=mid+1
    return ans
arr = [3, 5, 8, 15, 19]                # Sorted input array
x = 9
ind=(lowerbound(arr,x))
print("index",ind)

