def minimum(arr):
    n=len(arr)
    mini=float('inf')
    for i in range(n):
        mini=min(mini,arr[i])
    return mini
arr=[4,5,6,7,1,2]
print(minimum(arr))