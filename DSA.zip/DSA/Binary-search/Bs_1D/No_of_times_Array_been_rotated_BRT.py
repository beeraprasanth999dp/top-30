def rorated(arr):
    n=len(arr)
    for i in range(n-1):
        if(arr[i]>arr[i+1]):
            return i+1,arr[i+1]
    return 0
arr = [3, 4, 5, 1, 2]
res=rorated(arr)
print(res)