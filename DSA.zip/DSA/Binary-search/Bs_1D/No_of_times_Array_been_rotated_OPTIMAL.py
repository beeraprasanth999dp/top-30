def rot(arr):
    n=len(arr)
    low=0
    high=n-1
    while low<=high:
        mid=(low+high)//2
        if(arr[mid]>arr[mid+1]):
            low=mid+1
        else:
            high=mid-1
    return low
arr = [3, 4, 5, 1, 2]
res=rot(arr)
print(res)