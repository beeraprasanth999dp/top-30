def serchtraegt(arr,t):
    n=len(arr)
    for i in range(n):
        if(arr[i]==t):
            return i,arr[i]
    return -1
arr=[1,2,5,6,7,8]
t=5
print(serchtraegt(arr,t))