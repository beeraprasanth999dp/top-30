def check(arr,t):
    n=len(arr)
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]==t):
            return mid
        if arr[low]<arr[mid]:#left half sorted
            if arr[low]<= t and t< arr[mid]:
                high=mid-1
            else:
                low=mid+1
        else:# right half
            if arr[mid]<t <= arr[high]:
                low=mid+1
            else:
                high=mid-1
    return -1
arr = [4,5,6,7,0,1,2]
t = 0
res=check(arr,t)
print(res)
