def soarray(arr,t):
    n=len(arr)
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]==t):
            return mid
        if(arr[low]==arr[mid]==arr[high]):
            low=low+1
            high=high-1
            continue
        if(arr[low]<=arr[mid]):
            if(arr[low]<= t <arr[mid]):
                high=mid-1
            else:
                low=mid+1
        else:
            if(arr[mid]< t<= arr[high]):
                low=mid+1
            else:
                high=mid-1
    return -1
arr = [3,4,5,3,3,3,3]
t = 3
res=soarray(arr,t)
print((res))