def single(arr):
    n=len(arr)
    if n==1:
        return arr[0]
    for i in range(n):
        if i==0:
            if(arr[i]!=arr[i+1]):
                return arr[i]
        if i==n-1:
            if(arr[i]!=arr[i-1]):
                return arr[i]
        elif(arr[i-1]!=arr[i] !=arr[i+1]):
            return arr[i]
    return -1
arr=[1,1,2,2,3,3,4,5,5]
res=single(arr)
print(res)
