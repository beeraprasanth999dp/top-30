def upperBound(arr,x):
    n=len(arr)
    ans=n
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]>x):
            ans=mid
            high=mid-1
        else:
            low=mid+1
    return ans
arr=[2,3,6,7,8]
x=6
k=upperBound(arr,x)
print("index:",k)
