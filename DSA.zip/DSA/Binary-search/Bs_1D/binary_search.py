def binary(arr :[int],target:[int]):
    n=len(arr)
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if(arr[mid]==target):
            return mid,arr[mid]
        elif(target>arr[mid]):
            low=mid+1
        else:
            high=mid-1
    return -1
arr=[3,4,6,7,8,9,12,16,17]
target=9
k=binary(arr,target)
print(k)