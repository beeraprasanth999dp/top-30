def peak(arr):
    n=len(arr)
    for i in range(n):
        left=n==0 or arr[i]>arr[i-1]
        right=(n==arr[n-1]) or arr[i]>arr[i+1]
        if left and right:
            return arr[i]
    return -1
arr=[1,2,3,4,5,1]
res=peak(arr)
print(res)