def peak(arr):
    n=len(arr)
    low=0
    high=n-1
    while low<high:
        mid=(low+high)//2
        if(arr[mid]>arr[mid+1]):
            high=mid
        else:
            low=mid+1
    return low
arr = [1, 2, 1, 3, 5, 6, 4]
res=peak(arr)
print(res)
