def hash(number,arr):
    cnt=0

    for i in range(0,number):
        if(arr[i]==number):
            cnt+=1
            return cnt
number=1
arr=[1,2,3,2,4,3,5]
print(hash(number,arr))

