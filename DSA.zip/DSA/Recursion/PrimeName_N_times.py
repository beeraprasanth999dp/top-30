def recname(i,n):
    if(i>=n):
        return
    print("prasanth")
    recname(i+1,n)
recname(0,5)

