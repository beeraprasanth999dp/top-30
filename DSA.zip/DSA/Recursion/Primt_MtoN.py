def recursion(i,n):
    if(i>n):
        return
    print(i)
    recursion(i+1,n)
n=int(input("Enter a number"))
recursion(1,n)