def reFact(n):
    if(n==0):
        return 1
    return n * reFact(n-1)
n=reFact(6)
print((n))