def fib(n):
    if(n<=1):
        return n
    last=fib(n-1)
    Slast=fib(n-2)
    return last+Slast
n=5
print(fib(n))
0,1,1,2,3,4,5


    