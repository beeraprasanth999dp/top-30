def recRev(l,r):

    if(l>=r):
        return
    (a[r],a[l])
    recRev(r+1,r-1)
a=[1,4,5,6]
recRev(0,-1)


