def backtracking(i,n):
    if(i<1):
        return

    backtracking(i-1,n)
    print(i)
backtracking(5,5)