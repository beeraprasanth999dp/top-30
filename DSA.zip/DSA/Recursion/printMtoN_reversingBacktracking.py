def rev_back(i,n):
    if(i>n):
        return
    rev_back(i+1,n)
    print(i)
rev_back(1,5)