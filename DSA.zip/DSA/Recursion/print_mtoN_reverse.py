def rev_recursion(i,n):
    if(i<1):
        return
    print(i)
    rev_recursion(i-1,n)
rev_recursion(5,5)