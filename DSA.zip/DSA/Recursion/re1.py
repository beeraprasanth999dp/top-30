def rec( c,n):
    if c>n:
        return
    print(c)

    c+=1,n
    print(n)
    print()
n=10
rec=(1,n)


