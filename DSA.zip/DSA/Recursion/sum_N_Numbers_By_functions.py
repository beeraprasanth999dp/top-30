def resum(n):
    if(n==0):

        return 0

    return n+resum(n-1)

n=resum(5)

print(n)



