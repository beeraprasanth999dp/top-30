def recSum(i,sum):
    if i<1:
        print(sum)
        return
    recSum(i-1,sum+i)
recSum(5,0)