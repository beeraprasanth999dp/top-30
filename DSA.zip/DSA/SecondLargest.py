def brute_force(arr):


    sorted_arr=sorted(arr,reverse=True)
    return sorted_arr[1]





arr=[1,3,6,7,5,55,6,8]
print("Second largest:",brute_force(arr))