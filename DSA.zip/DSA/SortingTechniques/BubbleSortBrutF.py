def bubbleSort(arr):
    n=len(arr)
    for i in range(n-1,-1,-1):
        for j in range(i):
            if arr[j]>arr[j+1]:
                arr[j],arr[j+1]=arr[j+1],arr[j]
    print("After:",arr)
arr=[10,3,5,36,45,2]
print("before:",arr)
bubbleSort(arr)