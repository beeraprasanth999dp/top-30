def bubblesort(arr):
    n=len(arr)
    for i in range(n-1,-1,-1):
        swapped=False
        for j in range(i):
            if(arr[j]>arr[j+1]):
                arr[j],arr[j+1]=arr[j+1],arr[i]
                swapped=True
        if not swapped:
            break
    print("After:",arr)

arr=[2,54,65,16,5,6,44]
print("before:",arr)
bubblesort(arr)