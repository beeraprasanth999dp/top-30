def quickSort(arr,low,high):
    if low<high:
        povitIndex=partition(arr,low,high)
        quickSort(arr,low,povitIndex-1)
        quickSort(arr,povitIndex+1,high)
def partition(arr,low,high):
    pivot=arr[high]
    i=low-1
    for j in range(low,high):
        if arr[j]<=pivot:
            i+=1
            arr[i],arr[j]=arr[j],arr[i]
    arr[i+1],arr[high]=arr[high],arr[i+1]
    return i+1
arr=[10,7,8,9,1,5]

quickSort(arr, 0, len(arr) -1)
print(arr)
