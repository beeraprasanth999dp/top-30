def selectionsort(arr):
    n=len(arr)
    for i in range(n-1):
        min_indx=i#index value=0
        for j in range(i+1,n):
            if(arr[j]<arr[min_indx]):
                min_indx=j
        arr[i],arr[min_indx]=arr[min_indx],arr[i]
    print("After:")
    print(arr)
arr=arr=[3,6,5,-2,1,6,55,8,44,0,23]
print("before:",arr)
selectionsort(arr)
