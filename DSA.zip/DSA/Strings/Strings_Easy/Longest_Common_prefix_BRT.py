def comnp(s):
    if not s:
        return " "
    prefix=s[0]
    for i in range(len(prefix)):
        for word in s[1:]:
            if i>=len(word) and word[i]!=prefix[i]:
                return prefix[i]
        return prefix
s="flower,flow"
print(comnp(s))