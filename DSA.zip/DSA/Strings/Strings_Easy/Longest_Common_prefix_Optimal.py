def comprefix(s):
    if not s:
        return " "
    s.sort(s)
    first=s[0]
    last=s[-1]
    i=0
    while i<len(first) and first[i]==last[i]:
        i+=1
    return first[:i]
s=["flower,flow"]
print(comprefix(s))