def removeparn(s):
    cnt=0
    res=""
    for ch in s:
        if ch=="(":
            if cnt>0:
                res+=ch
            cnt+=1
        elif(ch==")"):
            cnt-=1
            if cnt>0:
                res+=ch
    return res
s="((()))"
print(removeparn(s))
   