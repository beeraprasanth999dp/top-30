n=153
org=n
temp=0
while n>0:
    digit=n%10
    temp+=digit**3
    n//=10
if temp==org:
        print("armstrong")
else:
    print("Not")