n=input("Enter name:")
rev=""
for char in n:
    rev=char+rev
if rev==n:
    print('palidrome')
else:
    print("not palidrome")
