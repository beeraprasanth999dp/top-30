n=121
org=n
rev=0
while n>0:
    digit=n%10
    rev=rev*10+digit
    n//=10

if rev==org:
    print("palindrome")
else:
        print("Not")