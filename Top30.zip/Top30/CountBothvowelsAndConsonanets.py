str='prasanth'
ocnt=0
ccnt=0
for ch in str:
    if ch in 'a,e,i,o,u,A,E,I,O,U, ':
        ocnt+=1
    elif ch.isalpha():
        ccnt+=1
print('vowels=',ocnt,'connants=',ccnt)