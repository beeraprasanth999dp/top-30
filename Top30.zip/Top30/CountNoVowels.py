str='prasanth vardhan'
count=0
for ch in str:
    if ch in 'a,e,i,o,u,A,E,I,O,U,':
        count+=1
print(count)