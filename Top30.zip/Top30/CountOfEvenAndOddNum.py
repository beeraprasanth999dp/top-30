m=3
n=7
ecnt=0
ocnt=0
for i in range(m,n+1):
    if i%2==0:
        ecnt+=1
    else:
        ocnt+=1

print("Even",ecnt)
print("odd",ocnt)



