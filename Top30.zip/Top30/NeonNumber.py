num=9
sq=num*num
sum=0
while sq>0:
    digit=sq%10
    sum=sum+digit
    sq//=10
if sum==num:
    print("neon")
else:
    print('Not Neon')