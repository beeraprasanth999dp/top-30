m=2
n=4
mul=1
for i in range(m,n+1):
    mul*=i
print(mul)
    