n="prasanth"
# rev=""
# for i in n:
#
#     rev=i+rev
#     print(rev)
str=n[::-1]
print(str)
