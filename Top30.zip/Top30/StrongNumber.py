num=145
sum_fact=0
temp=num
while temp>0:
    digit=temp%10
    fact=1
    for i in range(1,digit+1):

        fact*=i
    sum_fact+=fact
    temp//=10
if sum_fact==num:
    print(num,'is strong number:')
else:
    print(num," not Strong number:")
