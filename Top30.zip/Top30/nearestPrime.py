# Example number
n = 9

print(f"Finding nearest prime to {n}...")

# Step 1: Check if n is prime
is_prime = True
if n <= 1:
    is_prime = False
else:
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            is_prime = False
            break

if is_prime:
    print(f"{n} is prime!")
    result = n
else:
    print(f"{n} is not prime.")
    lower = n - 1
    higher = n + 1

    # Step 2: Check neighbors
    if lower > 1:
        prime_lower = True
        for i in range(2, int(lower ** 0.5) + 1):
            if lower % i == 0:
                prime_lower = False
                break
        if prime_lower:
            result = lower
            print(f"Nearest prime is {lower}")

    elif True:  # check higher
        prime_higher = True
        for i in range(2, int(higher ** 0.5) + 1):
            if higher % i == 0:
                prime_higher = False
                break
        if prime_higher:
            result = higher
            print(f"Nearest prime is {higher}")

print("Final result:", result)
