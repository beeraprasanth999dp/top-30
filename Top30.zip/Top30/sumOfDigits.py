n=123
temp=0
for i in range(n):
    d=n%10
    temp+=d
    n//=10
print(temp)
    